# -*- coding: utf-8 -*-
"""
This is a Python script to calculate 'SPAtial Hybrid 4' efficiency (SPAH4) which can be used to compare spatial patterns in two raster maps 

Detailed explanation goes here

The newly proposed SPAtial Hybrid 4 efficiency (SPAH4) metric  is proven to be robust 
and easy to interpret due to its three distinct and complementary components of correlation, variance, histogram matching and kurtosis ratio.

Created on Thu July 18 12:00:00 2024
@ authors:                 Eymen Berkay Yorulmaz, Elif Kartal, Mehmet Cüneyd Demirel
@ author's organization:   Department of Civil Engineering, Istanbul Technical University, Demirel's Hydrology and Remote Sensing LAB
@ author's webpage:        https://www.linkedin.com/in/eymen-berkay-yorulmaz-7203051b6/
@ author's email id:       yorulmaz21@itu.edu.tr

A libray with Python functions for calculation of 'SPAtial Hybrid 4' efficiency (SPAH4) metric.
"""

# import required modules
import os
import matplotlib.pyplot as plt
from matplotlib import gridspec
import numpy as np
import math
######################################################################################################################
def plot_SPAH4stats(sim,obs,Spah4, cc, alpha, histo, kurt, titlet):
    font = {'family': 'serif',
        'color':  'black',
        'weight': 'bold',
        'size': 18,
        }
        
    newpath = r'.\temp_Maps' 
    if not os.path.exists(newpath):
        os.makedirs(newpath) 
        

    obs=(obs-np.nanmin(obs))/(np.nanmax(obs)-np.nanmin(obs))
    sim=(sim-np.nanmin(sim))/(np.nanmax(sim)-np.nanmin(sim))
    
    bins=int(np.around(math.sqrt(len(obs)),0))
    
    hobs,binobs = np.histogram(obs,bins)
    hsim,binsim = np.histogram(sim,bins)

    fig, (ax1, ax2) = plt.subplots(1, 2 ,figsize=(10,16))
    gs = gridspec.GridSpec(1, 2, width_ratios=[1, 2], height_ratios=[1]) 
    ax1 = plt.subplot(gs[0])
    ax1.hist(obs, bins, alpha=0.5, label='obs')
    ax1.hist(sim, bins, alpha=0.5, label='sim')
    ax1.legend(loc='upper left')
    ax1.text(0.02, max(hsim)*2/3, r'$Histo Match$', fontdict=font)
    ax1.text(0.02, max(hsim)*2/3-max(hsim)/13, '{:.2f}'.format(round(histo, 2)), fontdict=font)
    
    ax1.set_title("SPAH4 is %.2f" %Spah4,fontdict=font)
    ax2 = plt.subplot(gs[1])
    ax2.scatter(obs,sim)
    
    ax2.text(-0.11, -0.16, r'$CORR:  $', fontdict=font)
    ax2.text(0.075,-0.16, np.around(cc,2), fontdict=font)
    ax2.text(0.275, -0.16, r'$CV: $', fontdict=font)
    ax2.text(0.375,-0.16, np.around(alpha,2), fontdict=font)
    ax2.text(0.575, -0.16, r'$KurtosisRatio: $', fontdict=font)
    ax2.text(0.950,-0.16, np.around(kurt,2), fontdict=font)
    z = np.polyfit(obs, sim, 1)
    p = np.poly1d(z)
    ax2.plot(obs,p(obs),"r--")
    ax2.set_title("See " + titlet+ "_map.png",fontdict=font)

    plt.tight_layout()
    
    
    fig.savefig(newpath+'/'+titlet+'.png', dpi=60,bbox_inches='tight')

    plt.show()
    plt.close(fig)

print('figure saved')




def plot_maps(sim,obs,titlet):

    obs2=obs#(obs-np.nanmin(obs))/(np.nanmax(obs)-np.nanmin(obs))
    sim2=sim#(sim-np.nanmin(sim))/(np.nanmax(sim)-np.nanmin(sim))
    
    font = {'family': 'serif',
        'color':  'black',
        'weight': 'bold',
        'size': 18,
        }    
        
    font2 = {'family': 'serif',
        'color':  'black',
        'weight': 'bold',
        'size': 12,
        }  
    newpath = r'.\temp_Maps' 
    if not os.path.exists(newpath):
        os.makedirs(newpath) 

    fig = plt.figure(figsize=(16, 10)) 
 
    
    plt.subplot(1, 2, 1)
    x=plt.imshow(sim2, interpolation='none',cmap='Spectral_r')
    plt.axis('off') 
    plt.colorbar(x,orientation ='horizontal',fraction=0.04, pad = 0.001, shrink=0.80)
    plt.title('SIM - '+titlet, fontdict=font)

    plt.text(0,0,r'BIAS: %.0f ' %(100*np.around((np.nanmean(np.abs(sim-obs))/np.nanmean(obs)),2))+'%', fontdict=font2)
    
    plt.subplot(1, 2, 2)
    y=plt.imshow(obs2, interpolation='none',cmap='Spectral_r')
    plt.axis('off') 
    plt.colorbar(y,orientation ='horizontal',fraction=0.04, pad = 0.001, shrink=0.80)
    plt.title('OBS - '+titlet, fontdict=font)
    
    
    foldersim = './temp_Maps/'
    filenamesim=titlet+'.jpg'
    fig.savefig(foldersim+filenamesim, dpi=60,bbox_inches='tight')

    plt.close(fig)

print('figure saved')
