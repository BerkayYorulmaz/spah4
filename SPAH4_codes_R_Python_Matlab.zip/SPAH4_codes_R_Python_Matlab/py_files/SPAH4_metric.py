# -*- coding: utf-8 -*-
"""
This is a Python script to calculate 'SPAtial Hybrid 4' efficiency (SPAH4) which can be used to compare spatial patterns in two raster maps 

Detailed explanation goes here

The newly proposed SPAtial Hybrid 4 efficiency (SPAH4) metric  is proven to be robust 
and easy to interpret due to its three distinct and complementary components of correlation, variance, histogram matching and kurtosis ratio.

Created on Thu July 18 12:00:00 2024
@ authors:                 Eymen Berkay Yorulmaz, Elif Kartal, Mehmet Cüneyd Demirel
@ author's organization:   Department of Civil Engineering, Istanbul Technical University, Demirel's Hydrology and Remote Sensing LAB
@ author's webpage:        https://www.linkedin.com/in/eymen-berkay-yorulmaz-7203051b6/
@ author's email id:       yorulmaz21@itu.edu.tr

A libray with Python functions for calculation of 'SPAtial Hybrid 4' efficiency (SPAH4) metric.

function:
    SPAH4 : SPAtial Hybrid 4 efficiency
"""

# import required modules
import numpy as np
from scipy.stats import variation,zscore,kurtosis
import math
######################################################################################################################
def filter_nan(s,o):
    data = np.transpose(np.array([s.flatten(),o.flatten()]))
    data = data[~np.isnan(data).any(1)]
    return data[:,0], data[:,1]
######################################################################################################################
def SPAH4(s, o):
    #remove NANs    
    s,o = filter_nan(s,o)
    
    bins=int(np.around(math.sqrt(len(o)),0))
    #compute corr coeff
    alpha = np.corrcoef(s,o)[0,1]
    #compute ratio of CV
    beta = variation(s)/variation(o)
    #compute zscore mean=0, std=1
    o=zscore(o)
    s=zscore(s)
    #compute histograms
    hobs,binobs = np.histogram(o,bins)
    hsim,binsim = np.histogram(s,bins)
    #convert int to float, critical conversion for the result
    hobs=np.float64(hobs)
    hsim=np.float64(hsim)
    #find the overlapping of two histogram      
    minima = np.minimum(hsim, hobs)
    #compute the fraction of intersection area to the observed histogram area, hist intersection/overlap index   
    gamma = np.sum(minima)/np.sum(hobs)
    #compute ratio of kurtosis coeff
    kappa = kurtosis(s, fisher= False)/kurtosis(o, fisher= False)
    
    #compute SPAH4 finally with four vital components
    SPAH4 = 1- np.sqrt( (alpha-1)**2 + (beta-1)**2 + (gamma-1)**2 + (kappa-1)**2  )  

    return SPAH4, alpha, beta, gamma, kappa
######################################################################################################################
 
