function [ spah4, alpha, beta, gamma, kappa ] = SPAH4_func( sim_vec,obs_vec )

% This is a MATLAB script to calculate 'SPAtial Hybrid 4' efficiency (SPAH4) which can be used to compare spatial patterns in two raster maps 
% Note that the NaN values in 2D maps are cleared first. Observed and Simulated two vectors (1D) are provided to the function.

% Detailed explanation goes here

% The newly proposed SPAtial Hybrid 4 efficiency (SPAH4) is proven to be robust 
% and easy to interpret due to its three distinct and complementary components of correlation, variance, histogram matching and kurtosis ratio.

% Created on Thu July 18 12:00:00 2024
% @ authors:            	 Eymen Berkay Yorulmaz, Elif Kartal, Mehmet C�neyd Demirel
% @ author's organization:   Department of Civil Engineering, Istanbul Technical University, Demirel's Hydrology and Remote Sensing LAB
% @ author's webpage:        https://www.linkedin.com/in/eymen-berkay-yorulmaz-7203051b6/
% @ author's email id:       yorulmaz21@itu.edu.tr
% 
% A libray with Matlab functions for calculation of 'SPAtial Hybrid 4' efficiency (SPAH4) metric.
 

%% correlation coefficient
cc=corrcoef(sim_vec,obs_vec);alpha=cc(1,2);

%% coefficient of variation
obs_CV=std(obs_vec)/mean(obs_vec);
sim_CV=std(sim_vec)/mean(sim_vec);
beta=sim_CV/obs_CV;

%% histogram match
obs_Zscore=zscore(obs_vec);
sim_Zscore=zscore(sim_vec);

bins=floor(sqrt(length(obs_vec)));

[N_obs,~] = histcounts(obs_Zscore,bins);
[N_sim,~] = histcounts(sim_Zscore,bins);


minOfHists = min([N_obs; N_sim], [], 1);
overlappedHist = sum(minOfHists);
histogram_match=overlappedHist/sum(N_obs);
gamma=histogram_match;

%% coefficient of kurtosis ratio
kappa=kurtosis(sim_vec)/kurtosis(obs_vec);

%% SPAH4
spah4 = 1- sqrt( (alpha-1)^2 + (beta-1)^2 + (gamma-1)^2 + (kappa-1)^2 );
end

